import grid_1 from "./grid-01.jpeg";
import grid_2 from "./grid-02.jpeg";
import grid_3 from "./grid-03.jpeg";
import grid_4 from "./grid-04.jpeg";
import step1 from "./step1.png";


export const assets = {
    grid_1,
    grid_2,
    grid_3,
    grid_4,
    step1
}